package SegundaActividad.AguadaGilma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundaActividadEntregableObligatoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
