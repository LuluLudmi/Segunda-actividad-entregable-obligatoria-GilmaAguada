package segundaactividad.aguadagilma.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.text.DecimalFormat; 

public class ConcesionariaService {

    // Lista que almacena todos los vehículos disponibles en la concesionaria.
    private List<Vehiculo> vehiculos;

    // =====================================================================
    // --- CONSTRUCTOR Y MÉTODOS DE CARGA DE DATOS ---
    // =====================================================================

    /**
     * Constructor de la clase ConcesionariaService.
     * Inicializa la lista de vehículos y carga algunos vehículos.
     */
    public ConcesionariaService() {
        this.vehiculos = new ArrayList<>();
        cargarVehiculos();
    }

    /**
     * Carga un conjunto predefinido de vehículos (autos y motos) a la lista.
     * Este método es privado porque solo se usa internamente al inicializar el
     * servicio.
     */
    private void cargarVehiculos() {
        // Se añaden instancias de Auto y Moto con sus respectivos atributos.
        vehiculos.add(new Auto("Peugeot", "206", 200000.00, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000.00, "125c"));
        vehiculos.add(new Auto("Peugeot", "208", 250000.00, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50, "160c"));
    }

    // =====================================================================
    // --- FUNCIONES Y PROCEDIMIENTOS (Cálculos y Lógica con impresión) ---
    // =====================================================================

    /**
     * Muestra la lista inicial de todos los vehículos.
     */
    public void mostrarListaInicialDeVehiculos() {
        System.out.println();
        vehiculos.forEach(System.out::println); // Utiliza el toString() de cada Vehiculo/Auto/Moto
        System.out.println();
        System.out.println("=============================");
        System.out.println();
    }

    // Muestra el vehículo con el precio más caro.
    
    public void mostrarVehiculoMasCaro() {
        vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed()) // Ordena de mayor a menor
                .limit(1) // Toma solo el primero (el más caro)
                // Se imprime la frase completa "Vehículo más caro: Marca Modelo"
                .forEach(v -> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Muestra el vehículo con el precio más barato.
     */
    public void mostrarVehiculoMasBarato() {
        vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio)) // Ordena de menor a mayor
                .limit(1) // Toma solo el primero (el más barato)
                // Se imprime la frase completa "Vehículo más barato: Marca Modelo"
                .forEach(v -> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    /**
     * Muestra el primer vehículo cuyo modelo contenga la letra especificada.
     * Si no lo encuentra, indica que no hay resultados.
     *
     * @param letra La letra a buscar como String.
     */
    public void mostrarVehiculoPorLetraEnModelo(String letra) {
        String caracterModeloBuscar = letra.toLowerCase(); // Convertimos la letra a minúscula para la búsqueda

        Vehiculo encontrado = null; // Variable para almacenar el vehículo encontrado

        for (Vehiculo v : vehiculos) { // Itera sobre cada vehículo en la lista
            if (v.getModelo().toLowerCase().contains(caracterModeloBuscar)) { // Comprueba si el modelo contiene la letra
                encontrado = v; // Si lo encuentra, lo guarda
                break; // Sale del bucle porque ya encontramos el primero
            }
        }

        if (encontrado != null) { // Si se encontró un vehículo (no es null)
            // Formato con punto en miles y coma en decimales, usando DecimalFormat.
            DecimalFormat formatoPrecioMiles = new DecimalFormat("#,##0.00");
            System.out.println("Vehículo que contiene en el modelo la letra ‘" + letra.toUpperCase() + "’: "
                    + encontrado.getMarca() + " " + encontrado.getModelo() + " $"
                    + formatoPrecioMiles.format(encontrado.getPrecio()));
        } else {
            System.out.println("No se encontró ningún vehículo con la letra ‘" + letra.toUpperCase() + "’ en el modelo.");
        }
        System.out.println();
        System.out.println("=============================");
        System.out.println();
    }

    /**
     * Muestra los vehículos ordenados por precio de mayor a menor.
     */
    public void mostrarVehiculosOrdenadosPorPrecioDescendente() {
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                // Se imprime solo marca y modelo.
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
        System.out.println();
        System.out.println("=============================");
        System.out.println();
    }

    /**
     * Muestra los vehículos ordenados por su orden natural (marca, modelo, precio).
     */
    public void mostrarVehiculosOrdenadosPorOrdenNatural() {
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        vehiculos.stream()
                .sorted() // Usa el compareTo de la clase Vehiculo
                // Se imprime el toString() completo.
                .forEach(System.out::println);
        System.out.println();
        System.out.println("=============================");
        System.out.println();
    }
}
