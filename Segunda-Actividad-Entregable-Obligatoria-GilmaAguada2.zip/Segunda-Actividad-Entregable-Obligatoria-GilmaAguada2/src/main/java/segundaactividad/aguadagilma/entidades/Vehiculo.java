package segundaactividad.aguadagilma.entidades;

import lombok.Getter;

import java.text.DecimalFormat;

@Getter
public abstract class Vehiculo implements Comparable<Vehiculo> {
    protected String marca;
    protected String modelo;
    protected double precio;

    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    /**
     * Método abstracto que obliga a las subclases a implementar una forma de
     * obtener detalles específicos de cada tipo de vehículo.
     * Este método no tiene implementación aquí porque cada vehículo (Auto, Moto)
     * tiene sus propias características únicas a detallar.
     * 
     * @return Un String que contiene los detalles específicos del vehículo (ej:
     *         "Puertas: 4", "Cilindrada: 600cc").
     */
    protected abstract String getDetallesEspecificos();

    // Se crea una instancia de DecimalFormat para asegurar que el precio se muestre
    // de forma legible.
    // El patrón "#,##0.00" formatea el número con separadores de miles y dos
    // decimales.

    @Override
    public String toString() {
        DecimalFormat formatoPrecio = new DecimalFormat("#,##0.00");
        return "Marca: " + marca + " // Modelo: " + modelo + getDetallesEspecificos() + " // Precio: $"
                + formatoPrecio.format(precio);
    }

    @Override
    public int compareTo(Vehiculo otroVehiculo) {
        // Este método compara dos vehículos para ordenarlos.
        // Construye una cadena con Marca, Modelo y Precio para ambos vehículos.
        // La comparación se hace textualmente (alfabéticamente) sobre estas cadenas.
        String thisVehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
        String paraVehiculo = otroVehiculo.getMarca() + "," + otroVehiculo.getModelo() + "," + otroVehiculo.getPrecio();
        return thisVehiculo.compareTo(paraVehiculo);
    }
}