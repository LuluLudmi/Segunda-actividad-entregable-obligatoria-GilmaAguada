package segundaactividad.aguadagilma.entidades;

import lombok.Getter;

@Getter
public class Moto extends Vehiculo {
    private String cilindrada;

    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    protected String getDetallesEspecificos() {
        return " // Cilindrada: " + cilindrada;
    }
}