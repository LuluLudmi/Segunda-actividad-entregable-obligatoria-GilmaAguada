package segundaactividad.aguadagilma.test;

import segundaactividad.aguadagilma.entidades.ConcesionariaService;

public class Concesionaria {
    public static void main(String[] args) {

        // Inicializamos la concesionaria para acceder a sus funciones y datos.
        ConcesionariaService concesionaria = new ConcesionariaService();

        // 1. Mostrar la lista inicial de todos los vehículos.
        // Se espera el formato completo (Marca: ... Precio: ...) y la línea divisoria.
        concesionaria.mostrarListaInicialDeVehiculos();

        // 2. Mostrar el vehículo más caro.
        // Se espera "Vehículo más caro: Marca Modelo".
        concesionaria.mostrarVehiculoMasCaro();

        // 3. Mostrar el vehículo más barato.
        // Se espera "Vehículo más barato: Marca Modelo".
        concesionaria.mostrarVehiculoMasBarato();

        // 4. Mostrar el vehículo que contiene la letra 'Y' en el modelo.
        // Se espera "Vehículo que contiene en el modelo la letra ‘Y’: Yamaha YBR
        // $80.500,50"
        // y la línea divisoria.
        concesionaria.mostrarVehiculoPorLetraEnModelo("Y");

        // 5. Mostrar los vehículos ordenados por precio de mayor a menor.
        // Se espera "Vehículos ordenados por precio de mayor a menor:" seguido de
        // "Marca Modelo" por cada vehículo y la línea divisoria.
        concesionaria.mostrarVehiculosOrdenadosPorPrecioDescendente();

        // 6. Mostrar los vehículos ordenados por su orden natural.
        // Se espera "Vehículos ordenados por orden natural (marca, modelo, precio):"
        // seguido del toString() completo de cada vehículo y la línea divisoria.
        concesionaria.mostrarVehiculosOrdenadosPorOrdenNatural();
    }
}
