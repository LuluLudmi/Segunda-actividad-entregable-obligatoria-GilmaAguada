package SegundaActividad.AguadaGilma.entidades;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor; // Necesario para la herencia con Lombok y un constructor vacío
import lombok.ToString;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/**
 * Clase abstracta que representa un vehículo genérico en la concesionaria.
 * Sirve como base para tipos específicos de vehículos como autos y motos.
 * Implementa la interfaz Comparable para definir un orden natural por marca,
 * modelo y precio.
 */

@Getter // Genera getters para todos los campos
@NoArgsConstructor // Genera constructor sin argumentos
@AllArgsConstructor // Genera constructor con todos los argumentos (marca, modelo, precio)
@EqualsAndHashCode // Genera equals y hashCode (incluye campos de la superclase si se sobreescribe)
@ToString(includeFieldNames = false) // Lombok generará toString, pero lo sobrescribiremos para el formato
public abstract class Vehiculo implements Comparable<Vehiculo> {
    protected String marca;
    protected String modelo;
    protected double precio;

    @Override
    public String toString() {
        // Configuramos DecimalFormatSymbols para asegurar ',' como separador decimal
        // y '.' como separador de miles, sin depender del Locale por defecto.
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator(',');
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,##0.00", symbols);

        return "Marca: " + marca + " // Modelo: " + modelo + " // Precio: $" + df.format(precio);
    }

    /**
     * Compara este vehículo con otro vehículo para establecer un orden natural.
     * La comparación se realiza primero por marca, luego por modelo y finalmente
     * por precio.
     * Esto implementa el método compareTo de la interfaz Comparable.
     * 
     * @param otroVehiculo El otro objeto Vehiculo con el que se va a comparar.
     * @return Retorna un valor negativo si este vehículo es "menor" que el especificado,
     * cero si son "iguales", o un valor positivo si este vehículo es "mayor".
     */

    @Override
    public int compareTo(Vehiculo otroVehiculo) {
        int resultadoMarca = this.marca.compareTo(otroVehiculo.marca);
        if (resultadoMarca != 0) {
            return resultadoMarca;
        }
        int resultadoModelo = this.modelo.compareTo(otroVehiculo.modelo);
        if (resultadoModelo != 0) {
            return resultadoModelo;
        }
        return Double.compare(this.precio, otroVehiculo.precio);
    }
}
