package SegundaActividad.AguadaGilma.entidades;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Clase ConcesionariaService gestiona las operaciones relacionadas con los
 * vehículos en la concesionaria.
 * Incluye la carga inicial de datos, búsqueda de vehículos (más caros, más
 * baratos, por criterio) y ordenamiento de la lista de vehículos.
 * Esta clase simula la lógica de negocio central de la concesionaria.
 */
public class ConcesionariaService {

    /**
     * Lista privada que almacena todos los objetos Vehiculo disponibles en la
     * concesionaria.
     * Esta es la colección principal sobre la que operan los métodos de servicio.
     */
    private List<Vehiculo> vehiculos;

    /**
     * Constructor de la clase ConcesionariaService.
     * Al instanciar esta clase, se inicializa la lista de vehículos
     * y se cargan los datos de prueba predefinidos.
     */
    public ConcesionariaService() {
        this.vehiculos = new ArrayList<>();
        // Se llama al método privado para cargar los vehículos iniciales al momento de
        // crear el servicio.
        cargarVehiculos();
    }

    /**
     * Carga la lista de vehículos iniciales en la concesionaria.
     * Este método privado se encarga de instanciar y añadir los objetos Auto y Moto
     * a la lista 'vehiculos'. Los datos son fijos para cumplir con el enunciado
     * y no requieren interacción del usuario.
     */
    private void cargarVehiculos() {
        // Se añaden los vehículos de tipo Auto
        vehiculos.add(new Auto("Peugeot", "206", 200000.00, 4));
        vehiculos.add(new Auto("Peugeot", "208", 250000.00, 5));
        // Se añaden los vehículos de tipo Moto
        vehiculos.add(new Moto("Honda", "Titan", 60000.00, "125c"));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50, "160c"));
    }

    /**
     * Imprime en la consola la información detallada de cada vehículo
     * presente en la lista proporcionada.
     * Utiliza el método 'toString()' sobrescrito en las clases Vehiculo, Auto y Moto
     * para formatear la salida de cada objeto.
     * 
     * @param listaVehiculos La lista a imprimir.
     * Se espera que esta lista contenga objetos Auto o Moto.
     */
    public void imprimirVehiculos(List<Vehiculo> listaVehiculos) {
        // Se utiliza forEach con una referencia a método (System.out::println)
        // para imprimir cada elemento de la lista de forma precisa.
        listaVehiculos.forEach(System.out::println);
    }

    /**
     * Encuentra el vehículo con el precio más alto de la lista de vehículos.
     * Este método utiliza la API de Streams de Java para realizar la búsqueda.
     * @return el precio más al
     */
    public Vehiculo encontrarVehiculoMasCaro() {
        // Utilizamos AtomicReference.get()para poder almacenar el resultado
        // del vehículo más caro dentro de una expresión lambda
        // cuando estoy procesando la lista de vehículos con Streams (.forEach()).
        // La utilizamos como un contenedor mutable
        // que las lambdas pueden modificar, permitiendo 'extraer' un único valor del
        // Stream.
        AtomicReference<Vehiculo> masCaro = new AtomicReference<>(null);

        vehiculos.stream()
                // 1. Ordena los vehículos por precio de mayor a menor (descendente).
                // Se usa un Comparator para comparar dobles y .reversed() para el orden
                // descendente.
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                // 2. Limita el stream a un solo elemento: el primero después de la ordenación,
                // que será el más caro. 
                .limit(1)
                // 3. Recorre sobre el (único) elemento restante en el stream y lo asigna a
                // masCaro.
                // Esta es una operación terminal que ejecuta las operaciones anteriores.
                .forEach(masCaro::set);

        // Se devuelve el vehículo encontrado, que será el más caro o null si no hay
        // vehículos.
        return masCaro.get();
    }

    /**
     * Encuentra el vehículo con el precio más bajo de la lista de vehículos de la
     * concesionaria.
     * @return el precio más bajo.
     * Retorna  null si la lista de vehículos está vacía.
     */
    public Vehiculo encontrarVehiculoMasBarato() {
        // Aquí también usamos AtomicReference para almacenar el resultado del stream.
        AtomicReference<Vehiculo> masBarato = new AtomicReference<>(null);

        vehiculos.stream()
                // 1. Ordena los vehículos por precio de menor a mayor (ascendente).
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio))
                // 2. Limita el stream a un solo elemento: el primero después de la ordenación,
                // que será el más barato.
                .limit(1)
                // 3. Asigna el vehículo encontrado a masBarato.
                .forEach(masBarato::set);

        return masBarato.get();
    }

    /**
     * Encuentra el primer vehículo en la lista cuyo modelo contenga la letra
     * especificada.
     * La búsqueda del modelo es insensible a mayúsculas y minúsculas para una mayor
     * flexibilidad.
     * Este método también utiliza Streams y AtomicReference.
     * @param letra El carácter a buscar en el modelo de los vehículos.
     * @return Retorna el vehiculo que contenga la letra en su modelo.
     * Retorna null si no se encuentra ningún vehículo con la letra.
     */
    public Vehiculo encontrarVehiculoConLetraEnModelo(char letra) {
        // Se convierte la letra a buscar a minúscula y a String para realizar una
        // comparación insensible a mayúsculas y minúsculas usando String.contains().
        final String letraStr = String.valueOf(Character.toLowerCase(letra));
        // AtomicReference para almacenar el primer vehículo que cumpla la condición.
        AtomicReference<Vehiculo> vehiculoEncontrado = new AtomicReference<>(null);

        vehiculos.stream()
                // 1. Filtra los vehículos. Solo se mantienen aquellos cuyo modelo (convertido a
                // minúscula) contiene la letra buscada (también en minúscula).
                .filter(v -> v.getModelo().toLowerCase().contains(letraStr))
                // 2. Limita el stream a un solo elemento. Una vez que encontramos el primer
                // vehículo
                // que cumple la condición de filtrado, no necesitamos seguir procesando el
                // resto.
                .limit(1)
                // 3. Asigna el vehículo filtrado y limitado a vehiculoEncontrado.
                .forEach(vehiculoEncontrado::set);

        return vehiculoEncontrado.get();
    }

    /**
     * Ordena la lista completa de vehículos por su precio de mayor a menor
     * (descendente).
     * Este método crea una nueva lista para no modificar el orden original de la
     * lista principal.
     * @return Retorna una nueva una lista ordenada por precio descendente.
     */
    public List<Vehiculo> ordenarVehiculosPorPrecioDescendente() {
        // Se crea una nueva lista a partir de la lista principal para no alterar el
        // orden original.
        List<Vehiculo> listaOrdenada = new ArrayList<>(vehiculos);
        // Se utiliza el método sort() de la interfaz List, aplicando un Comparator para
        // ordenar por precio de forma descendente.
        listaOrdenada.sort(Comparator.comparingDouble(Vehiculo::getPrecio).reversed());
        return listaOrdenada;
    }

    /**
     * Ordena la lista completa de vehículos según su "orden natural".
     * El orden natural está definido por la implementación del método compareTo
     * en la clase abstracta  Vehiculo, que ordena por marca, luego por modelo y 
     * finalmente por precio.
     * Se crea una nueva lista para no modificar el orden original.
     * @return Una nueva lista ordenada según el orden natural.
     */
    public List<Vehiculo> ordenarVehiculosPorOrdenNatural() {
        // Se crea una nueva lista para preservar el orden original de 'vehiculos'.
        List<Vehiculo> listaOrdenada = new ArrayList<>(vehiculos);
        // Se utiliza Collections.sort() que se basa en la implementación de la interfaz
        // Comparable
        // (método compareTo) en la clase Vehiculo para determinar el orden.
        Collections.sort(listaOrdenada);
        return listaOrdenada;
    }

    /**
     * Retorna la lista principal de vehículos que gestiona la concesionaria.
     * @return Retorna la lista de vehiculos actual.
     */
    public List<Vehiculo> getVehiculos() {
        return vehiculos;
    }
}