package SegundaActividad.AguadaGilma.entidades;

import lombok.Getter;
import lombok.NoArgsConstructor; // Necesario para la herencia con Lombok y un constructor vacío
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/**
 * Clase que representa una Moto, extendiendo la clase abstracta Vehiculo.
 * Contiene información específica de una moto, como la cilindrada.
 */

@Getter // Genera getters para 'cilindrada'
@NoArgsConstructor // Genera constructor sin argumentos
@EqualsAndHashCode(callSuper = true) // Incluye campos de la superclase en equals y hashCode
@ToString(callSuper = true, includeFieldNames = false) // Lombok generará toString, pero lo sobrescribiremos
public class Moto extends Vehiculo {
    private String cilindrada;

    /**
     * Constructor para crear una instancia de Moto.
     * @param marca      La marca de la moto.
     * @param modelo     El modelo de la moto.
     * @param precio     El precio de la moto.
     * @param cilindrada La cilindrada de la moto.
     */

    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio); // Llama al constructor de la clase padre
        this.cilindrada = cilindrada;
    }

    /**
     * Sobrescribe el método toString() para proporcionar una representación
     * formateada de la moto.
     * Incluye la información de la superclase (marca, modelo, precio) y la
     * cilindrada.
     * @return Retorna una cadena formateada que representa la moto.
     */

    @Override
    public String toString() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator(',');
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,##0.00", symbols);

        return "Marca: " + getMarca() + " // Modelo: " + getModelo() + " // Cilindrada: " + cilindrada + " // Precio: $"
                + df.format(getPrecio());
    }
}