package SegundaActividad.AguadaGilma.entidades;

import lombok.Getter;
import lombok.NoArgsConstructor; // Necesario para la herencia con Lombok y un constructor vacío
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/**
 * Clase que representa un Auto, extendiendo la clase abstracta Vehiculo.
 * Contiene información específica de un auto, como el número de puertas.
 */

@Getter // Genera getters para 'puertas'
@NoArgsConstructor // Genera constructor sin argumentos
@EqualsAndHashCode(callSuper = true) // Incluye campos de la superclase en equals y hashCode
@ToString(callSuper = true, includeFieldNames = false) // Lombok generará toString, pero lo sobrescribiremos
public class Auto extends Vehiculo {
    private int puertas;

    /**
     * Constructor para crear una instancia de Auto.
     * @param marca   La marca del auto.
     * @param modelo  El modelo del auto.
     * @param precio  El precio del auto.
     * @param puertas El número de puertas del auto.
     */
    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio); // Llama al constructor de la clase padre
        this.puertas = puertas;
    }

    /**
     * Sobrescribe el método toString() para proporcionar una representación
     * formateada del auto.
     * Incluye la información de la superclase (marca, modelo, precio) y el número
     * de puertas.
     * 
     * @return Retorna una cadena formateada que representa el auto.
     */

    @Override
    public String toString() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator(',');
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,##0.00", symbols);

        return "Marca: " + getMarca() + " // Modelo: " + getModelo() + " // Puertas: " + puertas + " // Precio: $"
                + df.format(getPrecio());
    }
}