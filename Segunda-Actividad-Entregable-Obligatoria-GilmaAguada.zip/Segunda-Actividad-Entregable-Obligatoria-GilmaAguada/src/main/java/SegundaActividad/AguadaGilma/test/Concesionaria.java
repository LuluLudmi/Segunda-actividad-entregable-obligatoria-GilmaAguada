package SegundaActividad.AguadaGilma.test;

import SegundaActividad.AguadaGilma.entidades.Vehiculo;
import SegundaActividad.AguadaGilma.entidades.ConcesionariaService;
import java.util.Scanner; // Nos permite leer la entrada del usuario directamente desde la consola. 

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;

/**
 * Clase principal que simula el funcionamiento de la concesionaria.
 * Contiene el método main para ejecutar la aplicación y mostrar la salida por
 * consola.
 */

public class Concesionaria {

    // Método principal que se ejecuta al iniciar la aplicación.
    // Realiza las operaciones de la concesionaria y muestra los resultados por
    // consola.

    public static void main(String[] args) {
        ConcesionariaService concesionariaService = new ConcesionariaService();

        DecimalFormatSymbols symbols = new DecimalFormatSymbols(); // Creamos un objeto symbols que nos permite definir
                                                                   // cómo se comportan los separadores de números.
        symbols.setDecimalSeparator(','); // Indicamos que la coma (,) sea el separador para los decimales.
        symbols.setGroupingSeparator('.'); // Decimos que el punto (.) sea el separador para los grupos de miles.
        DecimalFormat df = new DecimalFormat("#,##0.00", symbols); // Creamos el formateador de números (df) que va a
                                                                   // usar el patrón de moneda (#,##0.00)
                                                                   // y aplicará las reglas de separadores que definimos
                                                                   // en symbols.

        System.out.println("--- Lista Inicial de Vehículos ---");
        System.out.println();
        concesionariaService.imprimirVehiculos(concesionariaService.getVehiculos());
        System.out.println(); // Añade una línea vacía para más espacio
        System.out.println("=============================");
        System.out.println(); // Añade una línea vacía para más espacio

        // 2. Vehículo más caro
        Vehiculo masCaro = concesionariaService.encontrarVehiculoMasCaro();
        if (masCaro != null) { // Aseguramos de que solo intentamos trabajar con un vehículo si realmente lo
                               // encontramos.
            System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());
        }

        // 3. Vehículo más barato
        Vehiculo masBarato = concesionariaService.encontrarVehiculoMasBarato();
        if (masBarato != null) {
            System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());
        }
        // Hacer la búsqueda de la letra más genérica
        // Creamos un objeto Scanner para leer la entrada del usuario
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese la letra a buscar en los modelos de vehículos: ");
        // Leemos la primera letra que ingresa el usuario
        char letraABuscar = teclado.next().charAt(0);

        System.out.println(); // Salto de línea para separar la entrada del usuario del resultado

        // 4. Vehículo con letra ingresada en el modelo
        // Pasamos la variable 'letraABuscar' al método
        Vehiculo vehiculoConLetra = concesionariaService.encontrarVehiculoConLetraEnModelo(letraABuscar);
        if (vehiculoConLetra != null) {
            System.out.println(
                    "Vehículo que contiene en el modelo la letra ‘" + Character.toUpperCase(letraABuscar) + "’: "
                            + vehiculoConLetra.getMarca() + " "
                            + vehiculoConLetra.getModelo()
                            + " $" + df.format(vehiculoConLetra.getPrecio()));
        } else {
            // Un mensaje si no se encuentra ningún vehículo con esa letra
            System.out.println("No se encontró ningún vehículo con la letra ‘" + Character.toUpperCase(letraABuscar)
                    + "’ en el modelo.");
        }

        System.out.println();
        System.out.println("=============================");
        System.out.println();


        // 5. Vehículos ordenados por precio de mayor a menor

        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        List<Vehiculo> vehiculosPorPrecioDesc = concesionariaService.ordenarVehiculosPorPrecioDescendente();
        for (Vehiculo v : vehiculosPorPrecioDesc) {
            System.out.println(v.getMarca() + " " + v.getModelo());
        }
        System.out.println(); // Añade una línea vacía para más espacio
        System.out.println("=============================");
        System.out.println(); // Añade una línea vacía para más espacio
        
        // 6.Vehículos ordenados por orden natural (marca, modelo, precio)

        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        List<Vehiculo> vehiculosOrdenNatural = concesionariaService.ordenarVehiculosPorOrdenNatural();
        concesionariaService.imprimirVehiculos(vehiculosOrdenNatural);
        System.out.println(); // Añade una línea vacía para más espacio
        System.out.println("=============================");
        System.out.println(); // Añade una línea vacía para más espacio
    }
}